--create the view 'dept_biology' that returns instructors from biology department with attributes (id, name, salary).
--whenever new instructor added using dept_biology view, set automatically dept_name attribute in instructor table for new added data to 'Biology'
--test select/insert/select for your view and screenshot them.

create view dept_biology as
select id, "name", salary 
from instructor i 
where dept_name like 'Biology'
with check option;

CREATE FUNCTION biology_trigger()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO instructor (id, "name", dept_name, salary)
    VALUES (NEW.id, NEW.name, 'Biology', NEW.salary);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER dept_biology_trigger
INSTEAD OF INSERT ON dept_biology
FOR EACH ROW
EXECUTE FUNCTION biology_trigger();

select * from dept_biology;

INSERT INTO dept_biology (id, name, salary)
VALUES (80421, 'Linne', 100000);

select * from instructor where dept_name like 'Biology';


